let img;
let img1;
let img2;
let img3;
let img4;
let img5;
let img6;
let img7;
let music;
let music1;
let music2;
let description1;
let description2;
let description3;
let description4;
let description5;
let description6;
let description7;
let xAxis = 1200 ;
let pause = false;
let showDescription1 = false;
let showDescription2 = false;
let showDescription3 = false;
let showDescription4 = false;
let showDescription5 = false;
let showDescription6 = false;
let showDescription7 = false;
let startMusic =false;

function preload(){

  img = loadImage('background.jpeg');
  img1 = loadImage('atarabası.png');
  img2 = loadImage('atarabası2.png');
  img3 = loadImage('araba1.png');
  img4 = loadImage('araba3.png');
  img5 = loadImage('araba4.png');
  img6 = loadImage('araba2.png');
  img7 = loadImage('araba5.png');
  description1 = loadImage('description1.png');
  description2 = loadImage('description2.png');
  description3 = loadImage('description3.png');
  description4 = loadImage('description4.png');
  description5 = loadImage('description5.png');
  description6 = loadImage('description6.png');
  description7 = loadImage('description7.png');
  music = loadSound('music.mp3');
  music1 = loadSound('music1.mp3');
  music2 = loadSound('music2.mp3');

  }

function setup() {
  createCanvas(windowWidth,windowHeight)
}


function draw() {
    if (xAxis >= 5400) {
      xAxis = -300;
    }

    image(img,0,0,1920,1080);
    image(img1,xAxis,725);
    image(img2,xAxis-825,585);
    image(img3,xAxis-1430,620);
    image(img4,xAxis-2155,715);
    image(img5,xAxis-3210,590);
    image(img6,xAxis-3900,735);
    image(img7,xAxis-5000,705);
    xAxis += 2;

    if (showDescription1 && pause) {
      image(description1,xAxis,445,416,290);

      if (startMusic) {
        music.play();
      }
    }

    else if (showDescription2 && pause) {
      image(description2,xAxis-795,295,416,290);

      if (startMusic) {
        music1.play();
      }
    }
  else if (showDescription3 && pause) {
      image(description3,xAxis-1400,320,416,290);
    }
  else if (showDescription4 && pause) {
      image(description4,xAxis-1990,400,416,290);
      if (startMusic) {
        music2.play();
      }
    }
  else if (showDescription5 && pause) {
      image(description5,xAxis-3000,400,416,290);
    }
  else if (showDescription6 && pause) {
      image(description6,xAxis-3780,450,416,290);
    }
  else if (showDescription7 && pause) {
      image(description7,xAxis-300,350,416,290);
    }
}


function mouseDragged() {
  var position = mouseX - xAxis;
  console.log("position : " + position);
  if (mouseY >= 700 && mouseY <= 1000) {

    if (position >= 0 && position <= 500) {
       noLoop();
       pause = true;
       showDescription1 = true;
       startMusic=true;
    }
    else if (position <= -50 && position >= -500) {
      noLoop();
      pause = true;
      showDescription2 = true;
      startMusic=true;
    }
    else if (position <= -800 && position >= -1000) {
      noLoop();
      pause = true;
      showDescription3 = true;
    }
    else if (position <= -1300 && position >= -1700) {
      noLoop();
      pause = true;
      showDescription4 = true;
    }
    else if (position <= -2250 && position >= -3130) {
      noLoop();
      pause = true;
      showDescription5 = true;
    }
    else if (position <= -3250 && position >= -3900) {
      noLoop();
      pause = true;
      showDescription6 = true;
    }
    else if (position <= -5000 && position >= -4993) {
      noLoop();
      pause = true;
      showDescription7 = true;
    }
  }

}

function mouseReleased() {
  if (startMusic) {
    music.stop();
    music1.stop();
    music2.stop();
    startMusic = false;
  }

  if (pause == true) {
  loop();
  pause = false;
  }

  showDescription1 = false;
  showDescription2 = false;
  showDescription3 = false;
  showDescription4 = false;
  showDescription5 = false;
  showDescription6 = false;
  showDescription7 = false;
}
